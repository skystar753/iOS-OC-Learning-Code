//
//  LrcTool.m
//  LycPlayer
//
//  Created by Zetao on 20/5/2018.
//  Copyright © 2018 Zetao. All rights reserved.
//

#import "LrcTool.h"

@implementation LrcTool

- (instancetype)init
{
    self = [super init];
    if (self) {
        _timeArray = [NSMutableArray array];
        _wordArray = [NSMutableArray array];
    }
    return self;
}

//讀取plist文件
- (NSMutableArray *)arrayForContent {
    if (!_arrayForContent) {
        _arrayForContent = [NSMutableArray array];
        NSString *path = [[NSBundle mainBundle] pathForResource:@"Lrc" ofType:@"plist"];
        NSArray *array = [NSArray arrayWithContentsOfFile:path];
        for (NSDictionary *dict in array) {
            LrcModel *model = [LrcModel LrcModelWithDict:dict];
            [_arrayForContent addObject:model];
        }
        [_arrayForContent copy];
    }
    return _arrayForContent;
}

- (NSInteger)parseLrcAtIndex:(NSInteger)index withCurrentTime:(double)currentTime {
    LrcModel *model = self.arrayForContent[index];
    NSString *content = [NSString stringWithContentsOfFile:
                         [[NSBundle mainBundle] pathForResource:model.lyric
                                                         ofType:@"lrc"]
                                                  encoding:NSUTF8StringEncoding
                                                     error:nil];
    
    //使用@分割符分割歌詞與時間
    NSArray *sepArray = [content componentsSeparatedByString:@"["];
    for (int i = 5; i < sepArray.count; i++) {
        NSArray *arr = [sepArray[i] componentsSeparatedByString:@"]"];
        [self.timeArray addObject:arr[0]];
        [self.wordArray addObject:arr[1]];
    }
    
    NSInteger currentRow = 0;
    for (int j = 0; j < self.timeArray.count; j++) {
        NSInteger index = (j + 1) % self.timeArray.count;
        NSArray *arr = [self.timeArray[j] componentsSeparatedByString:@":"];
        NSArray *arrM = [self.timeArray[index] componentsSeparatedByString:@":"];
        double startTime = [arr[0] integerValue] * 60 + [arr[1] floatValue];
        double endTime = [arrM[0] integerValue] * 60 + [arrM[1] floatValue];
        if (currentTime > startTime)
        {
            if (currentTime < endTime) {
                currentRow = j;
            }
        }
        else
        {
            break;
        }
    }
    return currentRow;
}

- (NSURL *)getMusicURL:(NSInteger)index {
    LrcModel *model = self.arrayForContent[index];
    NSString *path = [[NSBundle mainBundle] pathForResource:model.music ofType:@"mp3"];
    NSURL *url = [NSURL fileURLWithPath:path];
    return url;
}
@end
