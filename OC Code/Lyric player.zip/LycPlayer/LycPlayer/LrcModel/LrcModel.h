//
//  LrcModel.h
//  LycPlayer
//
//  Created by Zetao on 20/5/2018.
//  Copyright © 2018 Zetao. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface LrcModel : NSObject

@property (nonatomic, copy) NSString *music;
@property (nonatomic, copy) NSString *lyric;
- (instancetype)initWithDict:(NSDictionary *)dict;
+ (instancetype)LrcModelWithDict:(NSDictionary *)dict;

@end
