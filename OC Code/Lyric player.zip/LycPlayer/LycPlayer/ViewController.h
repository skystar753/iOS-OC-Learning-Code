//
//  ViewController.h
//  LycPlayer
//
//  Created by Zetao on 20/5/2018.
//  Copyright © 2018 Zetao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LrcTool.h"
#import "LrcModel.h"

@interface ViewController : UIViewController
@property (nonatomic, strong) LrcTool *lrcTool;
@property (nonatomic, assign) NSInteger currentRow;
@property (weak, nonatomic) IBOutlet UITableView *lrcTableView;



@end

