//
//  AppDelegate.h
//  LycPlayer
//
//  Created by Zetao on 20/5/2018.
//  Copyright © 2018 Zetao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

