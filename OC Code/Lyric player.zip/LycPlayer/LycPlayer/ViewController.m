//
//  ViewController.m
//  LycPlayer
//
//  Created by Zetao on 20/5/2018.
//  Copyright © 2018 Zetao. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>
#import "LrcTool.h"
#import "LrcModel.h"
static const NSInteger kMusicNumber = 0;

@interface ViewController()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)AVAudioPlayer*player;
@property (weak, nonatomic) IBOutlet UISlider *slider;
@property (nonatomic,strong)NSTimer*timerone;


@end

@implementation ViewController

- (IBAction)play:(id)sender {
    [self.player play];
}

- (IBAction)pause:(id)sender {
    [self.player pause];
}
- (IBAction)stop:(id)sender {
    [self.player stop];
    self.player.currentTime = 0;
}

-(LrcTool *)lrcTool{
    if (!_lrcTool){
        _lrcTool = [[LrcTool alloc] init];
    }
    return _lrcTool;
}

-(AVAudioPlayer *)player{
    if (!_player) {
        NSURL *url = [self.lrcTool getMusicURL:kMusicNumber];
        _player = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:nil];
        [_player prepareToPlay];
    }
    return _player;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //給slider添加響應函數
    [self.slider addTarget:self action:@selector(playCurrentPos) forControlEvents:UIControlEventValueChanged];
    self.lrcTableView.delegate = self;
    self.lrcTableView.dataSource = self;
    
    //設置滑動條更新
    self.timerone = [NSTimer scheduledTimerWithTimeInterval:0.3 target:self selector:@selector(updateSlider) userInfo:nil repeats:YES];
    [self setupMainView];
    
}

-(void)updateSlider{
    self.slider.value = self.player.currentTime / self.player.duration;
}

-(void)playCurrentPos{
    self.player.currentTime = self.player.duration * self.slider.value;
}

- (void)setupMainView {
    
    [self.lrcTableView registerClass:[UITableViewCell class] forCellReuseIdentifier: @"CELL"];
     self.lrcTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
     [self.lrcTableView reloadData];
}


- (void)updateTime {
    NSInteger currentTime = _player.currentTime;
    [self.lrcTableView reloadData];
    _currentRow = [_lrcTool parseLrcAtIndex:kMusicNumber withCurrentTime:currentTime];
    if ( _currentRow > 0 ) {
        NSIndexPath *path = [NSIndexPath indexPathForRow:_currentRow inSection:0];
        [self.lrcTableView scrollToRowAtIndexPath:path
                                 atScrollPosition:UITableViewScrollPositionMiddle
                                         animated:YES];
    }
}



#pragma mark - TableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.lrcTool.wordArray.count - 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CELL"];
    
    if (indexPath.row == _currentRow)
    {
        cell.textLabel.textColor = [UIColor redColor];
    }
    else
    {
        cell.textLabel.textColor = [UIColor blackColor];
    }
    
    cell.backgroundColor = [UIColor lightGrayColor];
    cell.textLabel.textAlignment = NSTextAlignmentCenter;
    cell.textLabel.font = [UIFont systemFontOfSize:15];
    cell.textLabel.text = self.lrcTool.wordArray[indexPath.row];
    
    return cell;
}


@end
