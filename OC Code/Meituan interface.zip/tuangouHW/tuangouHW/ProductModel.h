//
//  ProductModel.h
//  tuangouHW
//
//  Created by SZT on 2017/3/19.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ProductModel : NSObject

@property(nonatomic,copy)NSString *name;
@property(nonatomic,copy)NSString *price;
@property(nonatomic,copy)NSString *number;
@property(nonatomic,copy)NSString *pic;
@property(nonatomic,copy)NSString *colour;



-(instancetype)initWithDict:(NSDictionary*)dict;
+(instancetype)productModelWithDict:(NSDictionary*)dict;


@end
