//
//  ViewController.m
//  tuangouHW
//
//  Created by SZT on 2017/3/17.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import "ViewController.h"
#import "ProductModel.h"
#import "ProductCell.h"

@interface ViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView *myView;
@property(nonatomic,strong)NSArray *productArray;
@end

@implementation ViewController



//懒加载productArray
-(NSArray *)productArray{
    if(!_productArray) {
        NSString *strPath = [[NSBundle mainBundle]pathForResource:@"product.plist" ofType:nil];
        NSArray *arrOne = [NSArray arrayWithContentsOfFile:strPath];
        NSMutableArray *arrTwo = [NSMutableArray array];
        for (NSDictionary *dict in arrOne) {
            ProductModel *model = [ProductModel productModelWithDict:dict];
            [arrTwo addObject:model];
        }
        _productArray = arrTwo;
    }
    return _productArray;
}

//懒加载myView
-(UITableView *)myView{
    if(!_myView){
        _myView = [[UITableView alloc]initWithFrame:self.view.frame ];
        _myView.dataSource = self;
        _myView.delegate = self;
        [self.view addSubview:_myView];
    }
    return _myView;
}

-(void)viewDidLoad {
    [super viewDidLoad];
    [self myView];
    [self productArray];
    self.myView.rowHeight = 100 ;
    
}


//section设置
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

//行数设置
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 6;
}

//创建cell
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *strIndentifier = @"mycell";
    ProductCell *cell = [tableView dequeueReusableCellWithIdentifier:strIndentifier];
    if(cell == nil){
        cell = [[[NSBundle mainBundle]loadNibNamed:@"ProductCell" owner:nil options:nil]firstObject];
        cell.model = self.productArray[indexPath.row];
    }
    return cell;
}

//状态栏隐藏
-(BOOL)prefersStatusBarHidden{
    return YES;
}








@end
