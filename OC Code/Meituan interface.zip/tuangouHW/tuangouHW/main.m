//
//  main.m
//  tuangouHW
//
//  Created by SZT on 2017/3/17.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
