//
//  ProductModel.m
//  tuangouHW
//
//  Created by SZT on 2017/3/19.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import "ProductModel.h"

@implementation ProductModel

-(instancetype)initWithDict:(NSDictionary*)dict;
{
    self = [super init];
    if (self){
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+(instancetype)productModelWithDict:(NSDictionary*)dict{
    return [[ProductModel alloc]initWithDict:dict];
}

@end
