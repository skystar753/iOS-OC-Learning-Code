//
//  ProductCell.m
//  tuangouHW
//
//  Created by SZT on 2017/3/19.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import "ProductCell.h"

@interface ProductCell()
@property (weak, nonatomic) IBOutlet UIImageView *pic;
@property (weak, nonatomic) IBOutlet UILabel *price;
@property (weak, nonatomic) IBOutlet UILabel *number;
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *colour;

@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;
@property (weak, nonatomic) IBOutlet UILabel *colourLabel;
@property (weak, nonatomic) IBOutlet UILabel *numberLabel;
@end


@implementation ProductCell


-(void)setModel:(ProductModel *)model{
    _model = model;
    self.pic.image = [UIImage imageNamed:model.pic];
    self.name.text = model.name;
    self.number.text = model.number;
    self.price.text = model.price;
    self.colour.text = model.colour;
    self.nameLabel.text = @"名称:";
    self.priceLabel.text = @"价格:";
    self.colourLabel.text = @"颜色:";
    self.numberLabel.text = @"已购数量:";
}


@end
