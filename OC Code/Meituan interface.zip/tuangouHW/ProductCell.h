//
//  ProductCell.h
//  tuangouHW
//
//  Created by SZT on 2017/3/19.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProductModel.h"



@interface ProductCell : UITableViewCell

@property (nonatomic,strong)ProductModel *model;

@end
