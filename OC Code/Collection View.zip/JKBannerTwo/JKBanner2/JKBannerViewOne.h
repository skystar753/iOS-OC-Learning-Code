//
//  JKBannerView1.h
//  JKBanner2
//
//  Created by SZT on 2017/4/3.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JKBannerViewOne;

@protocol JKBannerViewOneDelegate <NSObject>
-(void)bannerView:(JKBannerViewOne *)bannerView tappedAtIndex:(NSUInteger)index;

@end
@interface JKBannerViewOne : UIView<UIScrollViewDelegate>
@property(nonatomic,weak)id<JKBannerViewOneDelegate>delegate;
//只读
//assign基础数据类型
@property(nonatomic,readonly,assign)NSUInteger pageCount;
@property(nonatomic,readonly,assign)NSUInteger currentPage;

//读写
//copy适合不变的数组类型
@property(nonatomic,readwrite,copy)NSArray *images;
@property(nonatomic,readwrite,assign)BOOL pageControlEnabled;
@property(nonatomic,readwrite,assign)NSTimeInterval autoScrollTimeInterval;
@property(nonatomic,readwrite,assign)BOOL autoScrollEnabled;

-(instancetype)initWithImages:(NSArray<UIImage *>*)images frame:(CGRect)frame;
-(instancetype)initWithImagesNamed:(NSArray<NSString *>*)names frame:(CGRect)frame;

@end

