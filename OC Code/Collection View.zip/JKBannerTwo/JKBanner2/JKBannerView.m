//
//  JKBannerView.m
//  JKBanner2
//
//  Created by SZT on 2017/4/3.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import "JKBannerView.h"

@implementation JKBannerView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
