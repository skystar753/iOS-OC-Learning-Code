//
//  downloadIndicator2Tests.m
//  downloadIndicator2Tests
//
//  Created by SZT on 2017/5/10.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface downloadIndicator2Tests : XCTestCase

@end

@implementation downloadIndicator2Tests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
