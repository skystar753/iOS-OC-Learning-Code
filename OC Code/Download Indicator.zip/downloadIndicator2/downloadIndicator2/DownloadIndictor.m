//
//  downloadIndictor.m
//  downloadIndicator2
//
//  Created by SZT on 2017/5/10.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import "DownloadIndictor.h"

@implementation DownloadIndictor
const CGFloat startArc = (CGFloat)(M_PI)*3/2;

//初始化
-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if(self){
        self.progress = 0;
        self.frame = frame;
        self.backgroundColor = [UIColor clearColor];
        self.layer.cornerRadius = 10;
        self.layer.masksToBounds = YES;
    }
    return self;
}

//自动调用drawRect方法
-(void)setProgress:(CGFloat)progress{
    _progress = progress;
    [self setNeedsDisplay];
}

-(void)drawRect:(CGRect)rect{
    if((self.progress != 1)){
        CGFloat width = self.frame.size.width;
        CGContextRef context = UIGraphicsGetCurrentContext();
  //外边框
        CGContextSetFillColorWithColor(context, [UIColor colorWithWhite:0.5 alpha:0.8].CGColor);
        //左上角
        CGContextMoveToPoint(context, width/2, 0);
        CGContextAddLineToPoint(context, 0, 0);
        CGContextAddLineToPoint(context, 0, width/2);
        CGContextAddArcToPoint(context, 0, 0, width/2, 0, width/2);
        CGContextFillPath(context);
        CGContextDrawPath(context, kCGPathStroke);
        
        //右上角
        CGContextMoveToPoint(context, width/2, 0);
        CGContextAddLineToPoint(context, width, 0);
        CGContextAddLineToPoint(context, width, width/2);
        CGContextAddArcToPoint(context, width,0,width/2,0,width/2);
        CGContextFillPath(context);
        CGContextDrawPath(context, kCGPathStroke);
        
        //左下角
        CGContextMoveToPoint(context, 0, width/2);
        CGContextAddLineToPoint(context, 0, width);
        CGContextAddLineToPoint(context, width/2, width);
        CGContextAddArcToPoint(context,0,width,0,width/2,width/2);
        CGContextFillPath(context);
        CGContextDrawPath(context, kCGPathStroke);
        
        //右下角
        CGContextMoveToPoint(context,width/2,width);
        CGContextAddLineToPoint(context, width, width);
        CGContextAddLineToPoint(context, width, width/2);
        CGContextAddArcToPoint(context, width, width, width/2, width, width/2);
        CGContextFillPath(context);
        CGContextDrawPath(context, kCGPathStroke);
        
        //内部扇形
        CGContextMoveToPoint(context, self.frame.size.width/2, self.frame.size.height/2);
        if(self.progress == 0){
            CGContextAddArc(context, self.frame.size.width/2, self.frame.size.height/2, width/2 * 0.9, 0, M_PI *2, 0);
        }else{
            CGContextAddArc(context, self.frame.size.width/2, self.frame.size.height/2, width/2* 0.9, startArc, M_PI*2*self.progress + startArc, 1);
        }
        CGContextSetFillColorWithColor(context, [UIColor colorWithWhite:0.5 alpha:0.8].CGColor);
        CGContextFillPath(context);
        CGContextStrokePath(context);
    }
}

@end
