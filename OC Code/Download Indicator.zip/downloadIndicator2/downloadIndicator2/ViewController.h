//
//  ViewController.h
//  downloadIndicator2
//
//  Created by SZT on 2017/5/10.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

