//
//  ViewController.m
//  downloadIndicator2
//
//  Created by SZT on 2017/5/10.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import "ViewController.h"
#import "DownloadIndictor.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIImageView *icon = [[UIImageView alloc]initWithFrame:CGRectMake(100, 100, 100, 100)];
    icon.backgroundColor = [UIColor blackColor];
    icon.layer.cornerRadius = 10;
    icon.layer.masksToBounds = YES;
    [self.view addSubview:icon];

    DownloadIndictor *sectorProgressView = [[DownloadIndictor alloc]initWithFrame:CGRectMake(0, 0, icon.frame.size.width, icon.frame.size.height)];
    [icon addSubview:sectorProgressView];
    
    //进度条每隔一段时间自动更新
    [NSTimer scheduledTimerWithTimeInterval:1 repeats:YES block:^(NSTimer * _Nonnull timer) {
        sectorProgressView.progress += 0.1;
        if(sectorProgressView.progress >= 1){
            [timer invalidate];
            sectorProgressView.layer.hidden = YES;
        }
      }];
}



@end
