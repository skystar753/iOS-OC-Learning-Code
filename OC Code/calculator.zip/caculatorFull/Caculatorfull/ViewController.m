//
//  ViewController.m
//  Caculatorfull
//
//  Created by SZT on 2017/2/11.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *fristInput; //第一个数字输入框
@property (weak, nonatomic) IBOutlet UITextField *secondInput; //第二个数字输入框
@property (weak, nonatomic) IBOutlet UILabel     *result;      //结果显示框


@property (weak, nonatomic) IBOutlet UIButton *addButton;  //加法按钮
@property (weak, nonatomic) IBOutlet UIButton *subButton;  //减法按钮
@property (weak, nonatomic) IBOutlet UIButton *mulButton;  //乘法按钮
@property (weak, nonatomic) IBOutlet UIButton *divButton;  //除法按钮

@end

//viewcontroller 说明:http://blog.csdn.net/skewrain/article/details/12340671

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.addButton addTarget:self action:@selector(calculate:) forControlEvents:UIControlEventTouchUpInside];//addTarget函数在UIControl中
    [self.subButton addTarget:self action:@selector(calculate:) forControlEvents:UIControlEventTouchUpInside];
    [self.mulButton addTarget:self action:@selector(calculate:) forControlEvents:UIControlEventTouchUpInside];
    [self.divButton addTarget:self action:@selector(calculate:) forControlEvents:UIControlEventTouchUpInside];
    
}

// 触摸键盘外空白区域隐藏键盘
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}
    


-(void)calculate:(UIButton*)btn{
    //1 获取用户输入
    NSString *strFirstInput = self.fristInput.text;
    NSString *strSecondInput = self.secondInput.text;
    if( ([strFirstInput isEqualToString:@""]) || ([strSecondInput isEqualToString:@""])){
        self.result.text = @"请输入完整的数字";
        return;
    }
    float fResult = 0;
  
    //2 计算结果
    if([btn.titleLabel.text isEqualToString:@"加" ]){
        fResult = [strFirstInput floatValue] + [strSecondInput floatValue];
        self.result.text = [NSString stringWithFormat:@"%.02f",fResult];
        }
    else if([btn.titleLabel.text isEqualToString:@"减"]){
        fResult = [strFirstInput floatValue] - [strSecondInput floatValue];
        self.result.text = [NSString stringWithFormat:@"%.02f",fResult];
        }
    else if([btn.titleLabel.text isEqualToString:@"乘"]){
        fResult = [strFirstInput floatValue] * [strSecondInput floatValue];
        self.result.text = [NSString stringWithFormat:@"%.02f",fResult];
        }
    else if([btn.titleLabel.text isEqualToString:@"除"]){
        if([strSecondInput floatValue] == 0){
        self.result.text = @"除数不能为零"; //除数为零时显示除数不能为零
        }
        else{
        fResult = [strFirstInput floatValue] / [strSecondInput floatValue];
            self.result.text = [NSString stringWithFormat:@"%.02f",fResult];
        }
    }
}
    
@end
