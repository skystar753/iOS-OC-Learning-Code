//
//  main.m
//  ListReverse
//
//  Created by 孙泽涛 on 2016/12/22.
//  Copyright © 2016年 孙泽涛. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef struct Node_{
    int value;
    struct Node_ *next;
}Node;

Node *createNode(int value,Node *next){
    Node *node=malloc(sizeof(Node));
    node->value=value;
    node->next=next;
    return node;
}

void PrintList(Node *firstNode){
    for(Node *node=firstNode;node!=NULL;node=node->next){
        printf("Current node value %d\n",node->value);
    }
}

void ReverList(Node *firstNode){
    
    
}

Node* reverse(Node* head)
{
    Node* current = head;
    Node* next = NULL;
    Node *result = NULL;
    while (current != NULL) {
        next = current->next;
        current->next = result;
        result = current;
        current = next;
    }
    return result;
}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
    Node *current = createNode(0,NULL);
    Node *first = current;
    
    current->next = createNode (1,NULL);
    current = current->next;
    current->next = createNode (2,NULL);
    first = createNode(-1,first);
    printf("原链表数据:\n");
    PrintList(first);
    first=reverse(first);
    printf("逆序以后数据:\n");
    PrintList(first);
      
  }
    return 0;
}
