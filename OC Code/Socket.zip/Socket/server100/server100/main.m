//
//  main.m
//  server100
//
//  Created by zetao on 13/8/18.
//  Copyright © 2018年 zetao. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
