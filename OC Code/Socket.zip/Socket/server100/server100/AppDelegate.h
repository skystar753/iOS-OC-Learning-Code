//
//  AppDelegate.h
//  server100
//
//  Created by zetao on 13/8/18.
//  Copyright © 2018年 zetao. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

