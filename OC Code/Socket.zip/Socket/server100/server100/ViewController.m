//
//  ViewController.m
//  server100
//
//  Created by zetao on 13/8/18.
//  Copyright © 2018年 zetao. All rights reserved.
//

#import "ViewController.h"

#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>

@interface ViewController()
@property (weak) IBOutlet NSTextField *showText;
@property (weak) IBOutlet NSTextField *inputText;
@property(nonatomic,assign)int client_socket;



@end

@implementation ViewController
/* socket 服务器
 1、创建socket
 2、绑定地址和端口
 3、监听客户端的连接
 4、接受客户端的连接
 5、通讯（接受消息和发送信息）
 6、关闭socket
 */

- (void)viewDidLoad {
    [super viewDidLoad];
    //1 创建socket
    int server_socket = socket(AF_INET,SOCK_STREAM,0);//SOCK_STREAM 有连接
    if (server_socket == -1) {
        NSLog(@"创建socket失败",nil);
    }else{
        //2 绑定地址和端口
        struct sockaddr_in server_addr;
        server_addr.sin_len = sizeof(struct sockaddr_in);
        server_addr.sin_family = AF_INET;//Address famileise AF_INET互联网地址蔟
        server_addr.sin_port = htons(1234); //转成网络自节库
        server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
        bzero(&(server_addr.sin_zero),8);
        
        int bind_result = bind(server_socket,(struct sockaddr *)&server_addr,sizeof(server_addr));
        if(bind_result == -1) {
            NSLog(@"绑定端口失败",nil);
        }else {
            //3 监听客户端的连接
            if (listen(server_socket,5) == -1) {
                NSLog(@"监听失败",nil);
            } else {
                //4 接受客户端的连接
                struct sockaddr_in client_address;
                socklen_t address_len;
                
                dispatch_queue_t queue1 = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
                dispatch_async(queue1, ^{
                    int client_socket = accept(server_socket,(struct sockaddr *)& client_address,&address_len);
                    
                    if(client_socket == -1) {
                        NSLog(@"接受客户端连接失败",nil);
                    } else {
                        self.client_socket = client_socket;
                        while(1) {
                        //5 接收客户端传过来的数据
                            char *buf[1024] = {0};
                            int iReturn = recv(client_socket, buf, 1024, 0);
                            if(iReturn > 0){
                                NSString *str = [NSString stringWithCString:buf encoding:NSUTF8StringEncoding];
                                
                            //显示到界面上
                                dispatch_async(dispatch_get_main_queue(),^{
                                    self.showText.stringValue = str;
                                });
                            } else if (iReturn == -1)
                                break;
                        }
                    }
                });
            }
        }
    }
}
                                
                            
- (IBAction)sendclick:(id)sender {
    NSString *stringInput = self.inputText.stringValue;
    char*buf[1024] = {0};
    char*p1 = (char*)buf;
    p1 = [stringInput cStringUsingEncoding:NSUTF8StringEncoding];
    int a = 0;
    send(self.client_socket,p1,1024,a);
}



- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}


@end
