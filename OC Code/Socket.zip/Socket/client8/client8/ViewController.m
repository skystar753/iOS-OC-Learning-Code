//
//  ViewController.m
//  client8
//
//  Created by zetao on 14/8/18.
//  Copyright © 2018年 zetao. All rights reserved.
//

#import "ViewController.h"

#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>

@interface ViewController ()
@property (weak,nonatomic) IBOutlet UILabel *showText;
@property (weak,nonatomic) IBOutlet UITextField *sendText;
@property (nonatomic,assign) int iServerSocket;
@end
@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    int server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket == -1) {
        NSLog(@"socket error",nil);
    } else {
        struct sockaddr_in server_addr;
        server_addr.sin_len = sizeof(struct sockaddr_in);
        server_addr.sin_family = AF_INET;
        server_addr.sin_port = htons(1234);
        server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
        bzero(&(server_addr.sin_zero),8);
    

    dispatch_queue_t queue1 = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(queue1, ^{
        int a = connect(server_socket,(struct sockaddr *)&server_addr,sizeof
                        (struct sockaddr_in));
        if (a==0) {
            self.iServerSocket = server_socket;
            while(1) {
                char recv_mag[1024];
                long byte_num = recv(server_socket, recv_mag, 1024, 0);
                if (byte_num >0) {
                    //显示
                    NSString *str = [NSString stringWithUTF8String:recv_mag];
                    dispatch_async(dispatch_get_main_queue(),^{
                        self.showText.text = str;
                        NSLog(@"abc",nil);
                    });
                } else if (byte_num == -1)
                    break;
             }
          }
      });
    }
}


-(IBAction)send:(id)sender {
    NSString *strInput = self.sendText.text;
    char *buf[1024] = {0};
    char *p1 = (char*)buf;
    p1 = [strInput cStringUsingEncoding:NSUTF8StringEncoding];
    int a = 0;
    send(self.iServerSocket,p1,1024,0);
}



        
        
        
        
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
