//
//  EditViewController.m
//  ContactHw
//
//  Created by SZT on 2017/4/13.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import "EditViewController.h"
#import "ContactModel.h"

#define UseNameKey @"name"
#define PwdKey @"pwd"
#define RmbPwdKey @"rmb_pwd"


@interface EditViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameField;
@property (weak, nonatomic) IBOutlet UITextField *phoneField;
@property (weak, nonatomic) IBOutlet UIButton *saveBtn;
@property (weak, nonatomic) IBOutlet UINavigationItem *edit;

@end

@implementation EditViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.nameField.text = self.contactModel.name;
    self.phoneField.text = self.contactModel.phone;
    //添加观察者
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(textChange) name:UITextFieldTextDidChangeNotification object:self.nameField];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(textChange) name:UITextFieldTextDidChangeNotification object:self.phoneField];
}

-(void)textChange{
    self.saveBtn.enabled = (self.nameField.text.length && self.phoneField.text.length);
}


//设置添加电话弹出数字键盘
-(void)numberPad{
    _phoneField.keyboardType = UIKeyboardTypeNumberPad;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


//保存
- (IBAction)saveAction:(id)sender {
  //1.关闭当前页面
    [self.navigationController popViewControllerAnimated:YES];
  //2.通知代理
    if ([self.delegate respondsToSelector:@selector(editViewController:didSaveContact:)]) {
        //更新数据模型
        self.contactModel.name = self.nameField.text;
        self.contactModel.phone = self.phoneField.text;
        [self.delegate editViewController:self didSaveContact:self.contactModel];
    }
}

//编辑响应方法
- (IBAction)editAction:(UIBarButtonItem *)sender {
    if(self.nameField.enabled){
        self.nameField.enabled = NO;
        self.phoneField.enabled = NO;
        [self.view endEditing:YES];
        self.saveBtn.hidden = YES;
        sender.title = @"编辑";
        //还原数据
        self.nameField.text = self.contactModel.name;
        self.phoneField.text = self.contactModel.phone;
    }else{
        self.nameField.enabled = YES;
        self.phoneField.enabled = YES;
        [self.view endEditing:YES];
        self.saveBtn.hidden = NO;
        sender.title = @"取消";
    }
    
}
@end
