//
//  EditViewController.h
//  ContactHw
//
//  Created by SZT on 2017/4/13.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ContactModel,EditViewController;
@protocol EditViewControllerDelegate <NSObject>

@optional
-(void)editViewController:(EditViewController *)editVc didSaveContact:(ContactModel *)model;

@end

@interface EditViewController : UIViewController
@property(nonatomic,assign)id<EditViewControllerDelegate>delegate;
@property(nonatomic,strong)ContactModel *contactModel;



@end
