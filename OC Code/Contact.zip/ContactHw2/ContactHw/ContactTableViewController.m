//
//  ContactTableViewController.m
//  ContactHw
//
//  Created by SZT on 2017/4/13.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import "ContactTableViewController.h"
#import "ContactModel.h"
#import "AddViewController.h"
#import "EditViewController.h"

#define ContactFilePath [[NSSearchPathForDirectoriesInDomains (NSDocumentDirectory,NSUserDomainMask,YES)lastObject]stringByAppendingPathComponent:@"contacts.data"]


@interface ContactTableViewController ()<AddViewControllerDelegate,EditViewControllerDelegate>
@property(nonatomic,strong)NSMutableArray *contactArr;
@end

@implementation ContactTableViewController
-(NSMutableArray *)contactArr{
    if(!_contactArr){
        _contactArr = [NSKeyedUnarchiver unarchiveObjectWithFile:ContactFilePath];
        if(_contactArr == nil){
            _contactArr = [NSMutableArray array];
        }
    }
    return _contactArr;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    [self clearExtraLine:self.tableView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
#warning Incomplete implementation, return the number of sections
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
#warning Incomplete implementation, return the number of rows
    return self.contactArr.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"mycell"];
    ContactModel *contactModel = self.contactArr[indexPath.row];
    cell.textLabel.text = contactModel.name;
    cell.detailTextLabel.text = contactModel.phone;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

#pragma mark -AddViewController delegate
-(void)addContact:(AddViewController *)addVc didAddContact:(ContactModel *)contact{
    //1、添加数据模型
    [self.contactArr addObject:contact];
    //2、刷新表视图
    [self.tableView reloadData];
    //3、归档
    [NSKeyedArchiver archiveRootObject:self.contactArr toFile:ContactFilePath];
    
}

#pragma  mark - 去掉多余的线
-(void)clearExtraLine :(UITableView *)tableView{
    UIView *view = [[UIView alloc]init];
    view.backgroundColor = [UIColor clearColor];
    [self.tableView setTableFooterView:view];
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    

    id vc = segue.destinationViewController;
    if([vc isKindOfClass:[AddViewController class]]){//如果是跳转到添加联系人控制器
        //设置代理
        AddViewController *addVc = vc;
        addVc.delegate = self;
    }else if([vc isKindOfClass:[EditViewController class]]){
        EditViewController *editVc = vc;
        //取得选中的那一行
        NSIndexPath *path = [self.tableView indexPathForSelectedRow];
        editVc.contactModel = self.contactArr[path.row];
        editVc.delegate = self;
        
    }
}


#pragma mark - EditVC delegate
-(void)editViewController:(EditViewController *)editVc didSaveContact:(ContactModel *)model{
    [self.tableView reloadData];
    //归档
    [NSKeyedArchiver archiveRootObject:self.contactArr toFile:ContactFilePath];
}



#pragma mark - UITableView delegate
//删除数据
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(nonnull NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete){
       
        //1.删除数据模型
        [self.contactArr removeObjectAtIndex:indexPath.row];
        //2.刷新表视图
        [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationTop];
        //3.归档
        [NSKeyedArchiver archiveRootObject:self.contactArr toFile:ContactFilePath];
    }
}
   

- (IBAction)backAction:(id)sender {
    //初始化
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"是否注销" message:@"真的要注销吗" preferredStyle:UIAlertControllerStyleActionSheet];
    //添加按钮
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action){
        [self.navigationController popViewControllerAnimated:YES];
    }]];
    //弹出
    [self presentViewController:alert  animated:YES completion:NULL];
}
@end
