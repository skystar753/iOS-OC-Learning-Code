//
//  ContactModel.h
//  ContactHw
//
//  Created by SZT on 2017/4/13.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ContactModel : NSObject
@property(nonatomic,copy)NSString *name;
@property(nonatomic,copy)NSString *phone;


@end
