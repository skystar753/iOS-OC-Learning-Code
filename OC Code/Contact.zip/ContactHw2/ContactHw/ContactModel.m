//
//  ContactModel.m
//  ContactHw
//
//  Created by SZT on 2017/4/13.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import "ContactModel.h"

@implementation ContactModel

//编码
-(void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:self.name forKey:@"name"];
    [encoder encodeObject:self.phone forKey:@"phone"];
}
/*
 解析对象会调用这个方法
 需要解析哪些属性
*/
//解码
-(id)initWithCoder:(NSCoder *)decoder{
    if(self = [super init]){
        self.name = [decoder decodeObjectForKey:@"name"];
        self.phone = [decoder decodeObjectForKey:@"phone"];
    }
    return self;
}

@end
