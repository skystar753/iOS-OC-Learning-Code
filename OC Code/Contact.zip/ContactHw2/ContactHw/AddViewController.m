//
//  AddViewController.m
//  ContactHw
//
//  Created by SZT on 2017/4/13.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import "AddViewController.h"
#import "ContactModel.h"

@interface AddViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameField;
@property (weak, nonatomic) IBOutlet UITextField *phoneField;
@property (weak, nonatomic) IBOutlet UIButton *addBtn;

@end

@implementation AddViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(textChange) name:UITextFieldTextDidChangeNotification object:self.nameField];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(textChange) name:UITextFieldTextDidChangeNotification object:self.phoneField];
}

-(void)textChange{
      self.addBtn.enabled = (self.nameField.text.length && self.phoneField.text.length);
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    //让姓名文本框成为第一响应者（呼出键盘）
    [self.nameField becomeFirstResponder];
}

//设置添加电话弹出数字键盘
-(void)numberPad{
    _phoneField.keyboardType = UIKeyboardTypeNumberPad;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark -addData
//添加数据
- (IBAction)AddAction {
    //1.关闭当前视图控制器
    [self.navigationController popViewControllerAnimated:YES];
    //2、代理传值
 //   -(void)addContact:(AddViewController *)addVc didAddContact:(ContactModel *)contact;
    if([self.delegate respondsToSelector:@selector(addContact:didAddContact:)]){
        ContactModel *contactModel = [[ContactModel alloc]init];
        contactModel.name = self.nameField.text;
        contactModel.phone = self.phoneField.text;
        [self.delegate addContact:self didAddContact:contactModel];
    }
}




@end
