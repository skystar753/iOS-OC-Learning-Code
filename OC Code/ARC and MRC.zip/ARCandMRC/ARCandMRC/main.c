//
//  main.c
//  ARCandMRC
//
//  Created by 孙泽涛 on 2016/12/23.
//  Copyright © 2016年 孙泽涛. All rights reserved.
//


/*
 
MRC
1、中文名为手动引用计数。MRC需要手动配置 在Build Steting中 Objective-C Automatic Reference Counting改为NO。
2、使用alloc/new/copy/mutableCopy等，retainCount自加一，使用return函数retainCount自加一。
   使用release函数retainCount自减一，如果retaincount等于0则执行dealloc函数释放内存。
3、Autorelase Pool 提供了一种可以允许你向一个对象延迟发送release消息的机制：当我们把一个对象标记为autorelease时，
  这个对象的 retainCount 会+1，但是并不会发生 release。当这段语句所处的 autoreleasepool 进行 drain 操作时，
  所有标记了 autorelease 的对象的 retainCount 会被 -1。
 
 
ARC
1、中文名为自动引用计数，自动引用计数是一种新的内存管理机制。
2、在ARC模式下不能调用MAR相关的引用计数的调用方法，如：autorelease、retainCount、retain、 release等，否则会报错,
   虽然ARC不用手动的调用引用计数的代码，但是在编译时，编译器会自动生成相关的代码。
3、现在苹果公司推荐使用 ARC 来进行内存管理。
 
 
 两者的区别是：
1、MRC是一种比较老的内存管理方式，而ARC是一种新型的内存管理方式，新的工程自动使用ARC
2、MRC,手动引用计数器管理，申请的内存需要根据计数器的引用情况进行手动释放,如果未释放内存会造成内存泄露，而ARC将内存的使用
   和释放都交给编译器自动处理，使代码更简洁，编程更简单。
3、在ARC模式下不能调用MAR相关的引用计数的调用方法，如：autorelease、retainCount、retain、 release等，否则会报错,
   虽然ARC不用手动的调用引用计数的代码，但是在编译时，编译器会自动生成相关的代码。
4、MRC与ARC的管理机制是一样的，只是MRC由程序员来管理内存，而ARC由编译器来管理。
 

*/










