//
//  ViewController.swift
//  ReadPlistArray
//
//  Created by zetao on 10/8/18.
//  Copyright © 2018年 zetao. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        var arr = NSArray(contentsOf: NSURL(fileURLWithPath:Bundle.main.path(forResource: "arr",ofType:"plist")!) as URL)
        print(arr![0])
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

