//
//  ViewController.m
//  xmlParse
//
//  Created by zetao on 8/8/18.
//  Copyright © 2018年 zetao. All rights reserved.
//

#import "ViewController.h"
/*
 ios下有两张xml文件解释方式：SAX DOM
 SAX一行一行的去解析 小文件
 DOM全部读到内存，再去解析 大文件
 */

@interface ViewController ()<NSXMLParserDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    NSURL *urlFile = [NSURL fileURLWithPath:[[NSBundle mainBundle]
   pathForResource:@"my.xml" ofType:nil]];
    
    //初始化xml文件解码对象
    NSXMLParser *parser = [[NSXMLParser alloc]initWithContentsOfURL:urlFile];
    parser.delegate = self;
    
    //开始解析
    [parser parse];
    
}


-(void)parserDidStartDocument:(NSXMLParser *)parser{
    NSLog(@"开始解析xml",nil);
}

-(void)parserDidEndDocument:(NSXMLParser *)PARSER{
    NSLog(@"结束解析xml",nil);
}

-(void)parser:(NSXMLParser *)parser didStartElement:(nonnull NSString *)elementName namespaceURI:(nullable NSString *)namespaceURI qualifiedName:(nullable NSString *)qName attributes:(nonnull NSDictionary<NSString *,NSString *> *)attributeDict{
        if(attributeDict.count > 0){ //说明该标签有属性
            NSLog(@"读到标签 = %@ 属性 = %@",elementName,attributeDict);
    }else{
        NSLog(@"读到标签 = %@",elementName);
    }
}

-(void)parser:(NSXMLParser *)parser didEndElement:(nonnull NSString *)elementName namespaceURI:(nullable NSString *)namespaceURI qualifiedName:(nullable NSString *)qName{
  //  NSLog(@"标签 = %@ 结束",elementName);
}


-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    //剪切掉空格和换行
    NSString *strTemp = [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if(![strTemp isEqualToString:@""]){
        NSLog(@"读到字符串 = %@",string);
    }
}


@end
