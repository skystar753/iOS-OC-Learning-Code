//
//  main.m
//  xmlParse
//
//  Created by zetao on 8/8/18.
//  Copyright © 2018年 zetao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
