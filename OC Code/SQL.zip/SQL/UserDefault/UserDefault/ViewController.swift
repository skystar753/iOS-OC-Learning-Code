//
//  ViewController.swift
//  UserDefault
//
//  Created by zetao on 9/8/18.
//  Copyright © 2018年 zetao. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputTxt: UITextField!
    var ud:UserDefaults!
    override func viewDidLoad() {
       super.viewDidLoad()
        ud = UserDefaults.standard
        if let value = ud.object(forKey: "data"){
            inputTxt.text = value as? String
        }else{
            inputTxt.text = "No VALUE"
        }
    }
    @IBAction func saveBtnPressed(_ sender: Any) {
        let ud = UserDefaults.standard
        ud.set(inputTxt.text,forKey:"data")
        print("Saved")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

