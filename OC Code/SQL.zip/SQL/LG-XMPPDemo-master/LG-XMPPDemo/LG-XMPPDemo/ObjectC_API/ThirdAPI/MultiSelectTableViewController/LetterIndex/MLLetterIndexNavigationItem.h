//
//  MLLetterIndexNavigationItem.h
//  SecondhandCar
//
//  Created by molon on 14-1-8.
//  Copyright (c) 2014年 Molon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MLLetterIndexNavigationItem : UILabel

@property (nonatomic,assign) NSInteger index;//标识
@property (nonatomic,assign) BOOL isHighlighted; //是否高亮

@end
