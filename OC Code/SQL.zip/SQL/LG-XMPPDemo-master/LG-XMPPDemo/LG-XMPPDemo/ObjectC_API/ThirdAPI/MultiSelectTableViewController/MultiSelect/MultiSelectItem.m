//
//  MultiSelectItem.m
//  MultiSelectTableViewController
//
//  Created by molon on 6/7/14.
//  Copyright (c) 2014 molon. All rights reserved.
//

#import "MultiSelectItem.h"

@implementation MultiSelectItem

@end
