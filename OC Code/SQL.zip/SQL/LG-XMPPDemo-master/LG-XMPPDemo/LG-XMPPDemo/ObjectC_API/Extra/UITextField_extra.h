//
//  UITextField_extra.h
//  App
//
//  Created by jamie on 14-11-27.
//  Copyright (c) 2014年 Missionsky. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField(_extra)

/**
 * @brief 抖动
 */
- (void) shake;

@end
