//
//  ViewController.swift
//  showTips
//
//  Created by zetao on 9/8/18.
//  Copyright © 2018年 zetao. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var ud:UserDefaults!
    @IBOutlet weak var mySwitch: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        ud = UserDefaults.standard
        //what is that?
        mySwitch.isOn = ud.bool(forKey: "showTips")
        if mySwitch.isOn{
            UIAlertView(title: "提示", message: "今天要下雨，出门要带雨具哦!", delegate: nil, cancelButtonTitle: "好的").show()
        }
    }
    
    
    @IBAction func valueChangedHandle(_ sender: AnyObject) {
        ud.set(mySwitch.isOn,forKey: "showTips")
    }
    
   

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

