//
//  ViewController.m
//  file
//
//  Created by zetao on 7/8/18.
//  Copyright © 2018年 zetao. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //获取沙盒根目录
    NSString*strHome = NSHomeDirectory();
    NSLog(strHome,nil);
    
    //获取沙盒doc目录
    NSString *strDoc = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    NSLog(strDoc,nil);
     
    //获取沙盒lib目录
    NSString *strLib = [NSSearchPathForDirectoriesInDomains(NSLibraryDirectory,NSUserDomainMask,YES) firstObject];
    NSLog(strLib,nil);
    
    NSString*strTmp = NSTemporaryDirectory();
    NSLog(strTmp,nil);
}

//写文件
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    NSString *strDoc = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    //字符串添加后缀
    strDoc = [strDoc stringByAppendingString:@"/test.plist"];
    NSDictionary *dict = @{@"company":@"jkxy",@"teacher":@"lyg"};
    [dict writeToFile:strDoc atomically:YES];
}

- (IBAction)read:(id)sender {
    NSString *strDoc = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    //字符串添加后缀
    strDoc = [strDoc stringByAppendingString:@"/test.plist"];
    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile:strDoc];
    NSLog(@"%@",dict);
}

- (IBAction)write:(id)sender {
    NSString *strDoc = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    //字符串添加后缀
    strDoc = [strDoc stringByAppendingString:@"/test.plist"];
    
    //获取文件管理单例对象
    NSFileManager*manager = [NSFileManager defaultManager];
    
    BOOL bExit = [manager fileExistsAtPath:strDoc];
    
    if(!bExit) {
        NSDictionary *dict = @{@"company":@"jkxy",@"teacher":@"ime"};
        [dict writeToFile:strDoc atomically:YES];
    }
}
    
    
- (IBAction)createDirct:(id)sender {
    NSString *strDoc = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES) firstObject];
    strDoc = [strDoc stringByAppendingString:@"/abc"];
    NSFileManager *manger = [NSFileManager defaultManager];
    [manger createDirectoryAtPath:strDoc withIntermediateDirectories:YES attributes:nil error:nil];
}

- (IBAction)createFile:(id)sender {
    NSString *strDoc = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    strDoc = [strDoc stringByAppendingString:@"/abc/abc"];
    NSFileManager *manger = [NSFileManager defaultManager];
    [manger createFileAtPath:strDoc contents:nil attributes:nil];
}

- (IBAction)delFile:(id)sender {
   NSString *strDoc = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    strDoc = [strDoc stringByAppendingString:@"/abc/abc"];
    NSFileManager *manager = [NSFileManager defaultManager];
    [manager removeItemAtPath:strDoc error:nil];
}

- (IBAction)save:(id)sender {
    NSUserDefaults *manger = [NSUserDefaults standardUserDefaults];
    [manger setValue:@"jkxy" forKey:@"name"];
    [manger setInteger:18 forKey:@"age"];
}

-(IBAction)readerUserInfo:(id)sender{
    NSUserDefaults *manger = [NSUserDefaults standardUserDefaults];
    NSLog(@"%@",[manger valueForKey:@"name"]);
    NSLog(@"%d",[manger integerForKey:@"age"]);
    

}





@end








