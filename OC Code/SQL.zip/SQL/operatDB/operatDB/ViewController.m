//
//  ViewController.m
//  operatDB
//
//  Created by zetao on 9/8/18.
//  Copyright © 2018年 zetao. All rights reserved.
//

#import "ViewController.h"
#import <sqlite3.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
   
    //NSString*strPath = @"Users/jikexueyuan/Documents/mydatabase.sqlite";
    
    char*fileName = "/Users/zetao/Desktop/mydatabase.sqlite";
    
    //打开
    sqlite3*ppDB = NULL;
    int iReturn = sqlite3_open(fileName, &ppDB);
    if(iReturn == SQLITE_OK){
        NSLog(@"打开数据库成功");
    }else{
        NSLog(@"打开数据库失败 错误码 = %d",iReturn);
    }
    
    //读写 insert delete alter select
    
    //执行sql语句
    char*sql = "insert into student2016 (name,age) values ('王菲',46)";
    char*errMsg = NULL;
    int iReturnExe = sqlite3_exec(ppDB, sql, NULL,NULL,&errMsg);
    if(iReturnExe == SQLITE_OK){
        NSLog(@"执行sql语句成功");
    }else{
        NSLog(@"执行sql语句失败 错误码= %d",iReturnExe);
    }
    
    //查询数据库
    char*sql1 = "select * from student2016";
    sqlite3_stmt *ppStmt = NULL;
    int iReturn2 = sqlite3_prepare_v2(ppDB, sql1, -1, &ppStmt, NULL);
    if(iReturn2 == SQLITE_OK){
        NSLog(@"执行查询语句成功");
        while(sqlite3_step(ppStmt) == SQLITE_ROW){
            sqlite3_column_int(ppStmt,0);
            int iID = sqlite3_column_int(ppStmt,0);
            char*pName = (char*)sqlite3_column_text(ppStmt,1);
            char*pSex = (char*)sqlite3_column_text(ppStmt,2);
            int iAge = sqlite3_column_int(ppStmt,3);
            char*pTel = (char*)sqlite3_column_text(ppStmt,4);
            char*pAddress = (char*)sqlite3_column_text(ppStmt,5);
            NSLog(@"id = %d,姓名 = %@,性别 = %@,年龄 = %d 电话 = % 地址 = %@",iID,
                  [NSString stringWithUTF8String:pName],[NSString stringWithUTF8String:pSex],iAge,[NSString stringWithUTF8String:pTel],[NSString stringWithUTF8String:pAddress]);
        }
        //释放记录集
        sqlite3_finalize(ppStmt);
    }else{
        NSLog(@"执行查询语句 错误码 = %d",iReturn2);
    }
    
    //关闭
    int iRetClose = sqlite3_close(ppDB);
    if(iRetClose == SQLITE_OK){
        NSLog(@"关闭数据库成功");
    }else{
        NSLog(@"关闭数据库失败 错误码 = %d",iRetClose);
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
