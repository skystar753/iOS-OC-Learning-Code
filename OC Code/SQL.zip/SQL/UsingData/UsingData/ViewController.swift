//
//  ViewController.swift
//  UsingData
//
//  Created by zetao on 10/8/18.
//  Copyright © 2018年 zetao. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        var context = (UIApplication.sharedApplication.delegate as! AppDelegate).managedObjectContext
        var row:AnyObject = NSEntityDescription.insertNewObject(forEntityName: "Users", into: context)
        row.setValue("jikexueyuan",forKey:"name")
        row.setValue(1,forKey:"age")
        context.save(nil)
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

