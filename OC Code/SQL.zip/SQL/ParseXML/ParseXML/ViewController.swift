//
//  ViewController.swift
//  ParseXML
//
//  Created by zetao on 9/8/18.
//  Copyright © 2018年 zetao. All rights reserved.
//

import UIKit

class ViewController: UIViewController,XMLParserDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        // let path = Bundle.main.path(forResource: "iPhone100Voice", ofType: "mp3")
        // let baseURL = NSURL(fileURLWithPath: path!)
        //        let path = Bundle.main.path(forResource:"data",ofType:"xml")
        //        let parser = XMLParser(contentsOf:NSURL(fileURLWithPath:path)
        
       let parser = XMLParser(contentsOf:NSURL(fileURLWithPath: Bundle.main.path(forResource: "data",ofType:"xml")!) as URL)
       
        parser?.delegate = self
        parser?.parse()
    }
    
    //解析内容
    var currentNodeName:String!
    
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
       
//        print(elementName)
       
        currentNodeName = elementName
        
        //解析属性
        if elementName == "person" {
            if let age: AnyObject = attributeDict["age"] as AnyObject{
                print("age:\(age)")
            }
        }
    }
   
    func parser(parser:XMLParser,foundCharacters string: String!) {
        //print(string)
        var str = string.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
        if str! = ""{
            print("current node: \(currentNodeName),value:\(str)")
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

