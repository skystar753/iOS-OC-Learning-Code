//
//  ViewController.m
//  AutoLayoutCodeHw
//
//  Created by SZT on 2017/3/7.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
  
    //1、添加view到父窗口上
    UIView *orangeView = [[UIView alloc]init];
    orangeView.backgroundColor = [UIColor orangeColor];
    [self.view addSubview:orangeView];
    
    UIView *greenView = [[UIView alloc]init];
    greenView.backgroundColor = [UIColor greenColor];
    [self.view addSubview:greenView];
    
    UIView *blueView = [[UIView alloc]init];
    blueView.backgroundColor = [UIColor blueColor];
    [orangeView addSubview:blueView];
    
    
    //2、禁用autoresizing功能
    self.view.translatesAutoresizingMaskIntoConstraints = NO;
    orangeView.translatesAutoresizingMaskIntoConstraints = NO;
    greenView.translatesAutoresizingMaskIntoConstraints = NO;
    blueView.translatesAutoresizingMaskIntoConstraints = NO;
    
    //3、使用vfc创建orangeView和greenView
 
    NSArray *arrHOrangeGreen = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-20-[view1]-20-[view2(view1)]-20-|" options:0 metrics:nil views:@{@"view1":orangeView,@"view2":greenView}];
    [self.view addConstraints:arrHOrangeGreen];
    
    
    
    
    NSArray *arrVorange = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-40-[view(==200)]" options:0 metrics:nil views:@{@"view":orangeView}];
    [self.view addConstraints:arrVorange];
    
    NSArray *arrVGreen = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-40-[view(==200)]" options:0 metrics:nil views:@{@"view":greenView}];
        [self.view addConstraints:arrVGreen];
    
    //4、设置blueView与orangeView的关系
    //addconstraints 和 addconstraint有区别吗
    NSLayoutConstraint *blueTop = [NSLayoutConstraint constraintWithItem:blueView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:orangeView attribute:NSLayoutAttributeTop multiplier:1 constant:0];
    [orangeView addConstraint:blueTop];
    
    NSLayoutConstraint *blueLeft = [NSLayoutConstraint constraintWithItem:blueView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:orangeView attribute:NSLayoutAttributeLeft multiplier:1 constant:0];
    [orangeView addConstraint:blueLeft];
    
    NSLayoutConstraint *equalWidth = [NSLayoutConstraint constraintWithItem:blueView attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:orangeView attribute:NSLayoutAttributeWidth multiplier:0.5 constant:0];
    [orangeView addConstraint:equalWidth];
    
    NSLayoutConstraint *equalHeight = [NSLayoutConstraint constraintWithItem:blueView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:orangeView attribute:NSLayoutAttributeHeight multiplier:0.5 constant:0];
    [orangeView addConstraint:equalHeight];
    
    
}






@end
