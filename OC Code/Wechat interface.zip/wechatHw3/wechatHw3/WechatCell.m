//
//  wechatCell.m
//  wechatHw3
//
//  Created by SZT on 2017/4/17.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import "WechatCell.h"
#import "WechatModel.h"

@interface wechatCell()
@property (weak, nonatomic) IBOutlet UIImageView *pic;
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *say;


@end

@implementation wechatCell


-(void)setModel:(wechatModel *)model{
    _model = model;
    self.pic.image = [UIImage imageNamed:model.pic];
    self.name.text = model.name;
    self.say.text = model.say;
}



@end
