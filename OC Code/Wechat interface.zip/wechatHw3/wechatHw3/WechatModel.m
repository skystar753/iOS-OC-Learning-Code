//
//  wechatModel.m
//  wechatHw3
//
//  Created by SZT on 2017/4/17.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import "WechatModel.h"

@implementation wechatModel

-(instancetype)initWithDict:(NSDictionary*)dict
{
    self = [super init];
    if (self){
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+(instancetype)wechatModelWithDict:(NSDictionary*)dict{
    return [[wechatModel alloc]initWithDict:dict];
}


@end

