//
//  wechatNa.m
//  wechatHw3
//
//  Created by SZT on 2017/4/17.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import "WechatNavigationController.h"

@interface wechatNa ()

@end

@implementation wechatNa


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.tabBarItem.title = @"微信";
    self.tabBarItem.image = [UIImage imageNamed:@"tabbar_mainframe"];
    self.tabBarItem.selectedImage=[[UIImage imageNamed:@"tabbar_mainframeHL"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
   
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
