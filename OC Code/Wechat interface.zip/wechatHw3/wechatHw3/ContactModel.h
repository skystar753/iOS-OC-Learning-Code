//
//  contactModel.h
//  wechatHw3
//
//  Created by SZT on 2017/4/18.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface contactModel : NSObject
@property(nonatomic,copy)NSString *name;
@property(nonatomic,copy)NSString *pic;

-(instancetype)initWithDict:(NSDictionary*)dict;
+(instancetype)contactModelWithDict:(NSDictionary*)dict;



@end
