//
//  contactModel.m
//  wechatHw3
//
//  Created by SZT on 2017/4/18.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import "ContactModel.h"

@implementation contactModel

-(instancetype)initWithDict:(NSDictionary*)dict
{
    self = [super init];
    if (self){
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}


+(instancetype)contactModelWithDict:(NSDictionary *)dict{
    return [[contactModel alloc]initWithDict:dict];
}



@end
