//
//  contactCell.h
//  wechatHw3
//
//  Created by SZT on 2017/4/18.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ContactModel.h"
@interface contactCell : UITableViewCell
@property(nonatomic,strong)contactModel *model;



@end
