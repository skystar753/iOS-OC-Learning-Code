//
//  ViewController.h
//  wechatHw3
//
//  Created by SZT on 2017/4/17.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

