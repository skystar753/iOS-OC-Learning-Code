//
//  contactCell.m
//  wechatHw3
//
//  Created by SZT on 2017/4/18.
//  Copyright © 2017年 SZT. All rights reserved.
//

#import "ContactCell.h"

@interface contactCell()

@property (weak, nonatomic) IBOutlet UIImageView *pic;
@property (weak, nonatomic) IBOutlet UILabel *name;


@end

@implementation contactCell


-(void)setModel:(contactModel *)model{
    _model = model;
    self.pic.image = [UIImage imageNamed:model.pic];
    self.name.text = model.name;
}



@end
